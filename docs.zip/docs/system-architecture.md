# CampusOS Prototype Architecture

## Overview
CampusOS is a dual-surface prototype (web + mobile) that connects four core pillars through a shared AI/ML inference layer and an event sync API.

## Core Pillars
- The Daily Pulse: live mess menu + AI mail summarizer
- The Student Exchange: lost & found, buy/sell marketplace, travel sharing
- The Explorer's Guide: nearby hub discovery and navigation insights
- The Academic Cockpit: timetable, LMS lite, academic intelligence

## High-Level Architecture
```mermaid
flowchart TB
  Web["Web App (HTML/JS)"] --> API
  Mobile["Mobile App (React Native)"] --> API
  API["FastAPI Backend"] --> ML["AI/ML Inference (TF-IDF + Logistic)" ]
  API --> Store["Session Memory + Event Stream"]
  API --> Pillars["Pillars Services"]
  ML --> Pillars
  Store --> ML
```

## AI/ML Layer
- Model: TF-IDF vectorizer + Logistic Regression classifier
- Training data: seed messages labeled by pillar intent
- Outputs:
  - Intent label (pillar routing)
  - Confidence score
  - Keyword summary for mail and listings

## Sync Layer
- Endpoint: `/sync/event`
- Stores recent events per user
- Uses aggregated events to recommend the next best action

## Data Flow (Example)
1. User submits a mail snippet on web or mobile.
2. Backend runs intent classification and keyword extraction.
3. Response returns a summary + recommended pillar (Daily Pulse).
4. Event is stored and combined with the next interactions to guide a smarter flow.

## Extensibility
- Replace the classifier with a fine-tuned LLM or transformer model.
- Add persistent storage (PostgreSQL + Redis) for real-time sync.
- Connect to real LMS, email, and campus services.
