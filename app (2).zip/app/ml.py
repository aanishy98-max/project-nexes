from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List, Tuple

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "pulse_intent.joblib")
DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "seed_messages.csv")


@dataclass
class Prediction:
    label: str
    confidence: float


def _build_pipeline() -> Pipeline:
    return Pipeline(
        steps=[
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=5000)),
            ("clf", LogisticRegression(max_iter=1000)),
        ]
    )


def train_or_load_model() -> Pipeline:
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)

    data = pd.read_csv(DATA_PATH)
    pipeline = _build_pipeline()
    pipeline.fit(data["text"], data["label"])
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(pipeline, MODEL_PATH)
    return pipeline


def predict_intent(model: Pipeline, text: str) -> Prediction:
    probabilities = model.predict_proba([text])[0]
    labels = model.classes_
    best_idx = int(probabilities.argmax())
    return Prediction(label=str(labels[best_idx]), confidence=float(probabilities[best_idx]))


def keyword_summary(text: str, top_k: int = 6) -> List[str]:
    vectorizer = TfidfVectorizer(stop_words="english", max_features=1000)
    tfidf = vectorizer.fit_transform([text])
    scores = tfidf.toarray()[0]
    terms = vectorizer.get_feature_names_out()
    ranked = sorted(zip(terms, scores), key=lambda x: x[1], reverse=True)
    return [term for term, score in ranked[:top_k] if score > 0]


def route_features(label: str) -> List[str]:
    routing = {
        "mess_menu": ["daily_pulse", "live_mess_menu"],
        "mail": ["daily_pulse", "mail_summarizer"],
        "lost_found": ["student_exchange", "lost_found"],
        "buy_sell": ["student_exchange", "marketplace"],
        "travel": ["student_exchange", "travel_sharing"],
        "nearby": ["explorers_guide", "nearby_hub"],
        "navigate": ["explorers_guide", "navigate_smarter"],
        "timetable": ["academic_cockpit", "live_timetable"],
        "lms": ["academic_cockpit", "lms_lite"],
        "academic": ["academic_cockpit", "academic_intelligence"],
    }
    return routing.get(label, ["daily_pulse"])
