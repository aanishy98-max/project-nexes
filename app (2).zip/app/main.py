from __future__ import annotations

import datetime as dt
from typing import Dict, List

from fastapi import FastAPI
from pydantic import BaseModel, Field

from .ml import keyword_summary, predict_intent, route_features, train_or_load_model

app = FastAPI(title="CampusOS Prototype API", version="0.1.0")
model = train_or_load_model()

SESSION_MEMORY: Dict[str, List[dict]] = {}


class PulseRequest(BaseModel):
    user_id: str
    text: str = Field(..., description="Email or announcement text")


class ListingRequest(BaseModel):
    user_id: str
    title: str
    description: str
    price: float


class TravelRequest(BaseModel):
    user_id: str
    origin: str
    destination: str
    time: str


class SyncEvent(BaseModel):
    user_id: str
    event_type: str
    payload: dict


@app.get("/health")
async def health() -> dict:
    return {"status": "ok", "timestamp": dt.datetime.utcnow().isoformat() + "Z"}


@app.post("/pulse/summary")
async def pulse_summary(req: PulseRequest) -> dict:
    intent = predict_intent(model, req.text)
    summary = keyword_summary(req.text)
    features = route_features(intent.label)
    _remember(req.user_id, {"intent": intent.label, "summary": summary})
    return {
        "intent": intent.label,
        "confidence": intent.confidence,
        "summary_keywords": summary,
        "suggested_features": features,
    }


@app.post("/exchange/score-listing")
async def score_listing(req: ListingRequest) -> dict:
    joined = f"{req.title}. {req.description}"
    intent = predict_intent(model, joined)
    quality = min(0.95, 0.5 + intent.confidence / 2)
    tags = keyword_summary(joined)
    _remember(req.user_id, {"listing_quality": quality, "tags": tags})
    return {
        "quality_score": quality,
        "suggested_tags": tags,
        "exchange_lane": route_features(intent.label),
    }


@app.post("/exchange/travel-match")
async def travel_match(req: TravelRequest) -> dict:
    text = f"{req.origin} to {req.destination} at {req.time}"
    intent = predict_intent(model, text)
    _remember(req.user_id, {"travel": text, "confidence": intent.confidence})
    return {
        "match_intent": intent.label,
        "confidence": intent.confidence,
        "recommended_channel": "Cab-Pool Coordinator",
    }


@app.post("/sync/event")
async def sync_event(req: SyncEvent) -> dict:
    _remember(req.user_id, {"event": req.event_type, "payload": req.payload})
    last_events = SESSION_MEMORY.get(req.user_id, [])[-5:]
    stitched_text = " ".join([str(e) for e in last_events])
    intent = predict_intent(model, stitched_text)
    return {
        "next_best_action": route_features(intent.label),
        "context_confidence": intent.confidence,
        "recent_events": last_events,
    }


def _remember(user_id: str, payload: dict) -> None:
    SESSION_MEMORY.setdefault(user_id, []).append(
        {"at": dt.datetime.utcnow().isoformat() + "Z", **payload}
    )
